export const environment = {
  production: true,
  url_hosting: 'https://ingenio-peru.com/apiingenio/api/',

  api_correo: {
    _nombre_correo_corporativo: 'ventas@ingenio-peru.com,pablogonzalescastillo@gmail.com',
    _envio_masivo_correo: 'correo/envio_masivo_correo/',
  },
};
